<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="css/footer.css" rel="stylesheet" type="text/css"/>
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    </head>
    <body>
        <div class="back">      
            <div class="link">
                <div class="head"><p>Visit Our Website</p>
                    <ul class="n1">
                        <li><a href="Home.php"><ion-icon name="home-outline"></ion-icon> Official Website</a></li>     
                        <li><a href="https://www.facebook.com/tarucmusicsociety/"><ion-icon name="logo-facebook"></ion-icon> Facebook</a></li>
                        <li><a href="https://www.youtube.com/"><ion-icon name="logo-youtube"></ion-icon> YouTube</a></li>
                        <li><a href="https://twitter.com/"><ion-icon name="logo-twitter"></ion-icon> Twitter</a></li>
                        <li><a href="https://www.instagram.com/"><ion-icon name="logo-instagram"></ion-icon> Instagram</a></li>

                    </ul>
                </div>
                <div class="head"><p>Contact Us</p>
                    <ul class="n2">
                        <li><a href="https://web.whatsapp.com/"><ion-icon name="logo-whatsapp"></ion-icon> Whatsapp</a></li>
                        <li><a href="https://www.wechat.com/"><ion-icon name="logo-wechat"></ion-icon> Wechat</a></li>
                        <li><a href="https://discord.com/"><ion-icon name="logo-discord"></ion-icon> Discord</a></li>
                        <li><a href="musicsociety.tarucpenang@gmail.com"><ion-icon name="mail-outline"></ion-icon> Email</a></li>
                        <li><a href="tel:+601156994938"><ion-icon name="call-outline"></ion-icon></ion-icon> Call</a></li>

                    </ul></div>
                <div class="head"><p>Description</p>
                    <ul class="n3">
                        <li>Our Music Society was founded in the year 2000.</li>
                        <li>Our Aim and Objective -To foster harmony among</li>
                        <li>This website is &copy; with Music Society</li>
                        <li>&nbsp;</li>
                        <li>&nbsp;</li>


                    </ul></div>

            </div>

        </div>
    </body>
</html>
